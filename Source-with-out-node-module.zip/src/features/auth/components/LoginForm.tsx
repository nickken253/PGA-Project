import React from 'react'
import { Formik } from 'formik'
import { useLogin } from '../../../lib/auth';
import { axios } from '../../../lib/axios';
import style from './LoginForm.module.scss';
import {
  loginEmailAndPassword,
  LoginCredentials,
  AuthUser,
  UserResponse,
} from "../../../features/auth";
import storage from '../../../utils/storage';
import { useEffect, useState } from 'react';
import { on } from 'events';
interface LoginFormProps {
  onSuccess: () => void;
}

export const LoginForm = ({ onSuccess }: LoginFormProps) => {
  const login = useLogin();
  const [isValidEmail, setIsValidEmail] = useState(true);
  const [isValidPassword, setIsValidPassword] = useState(true);
  const [emailErrorMessages, setEmailErrorMessages] = useState('');

  useEffect(() => {
    const token = storage.get('token');
    if (token) {
      console.log('token', token);
      onSuccess();
    }
  },);
  return (
    <div>
      <Formik
        initialValues={{ email: '', password: '' }}
        validate={values => {
          const errors: any = {}
          if (!values.email) {
            errors.email = 'Required'
          } else if (
            !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(
              values.email
            )
          ) {
            errors.email = 'Invalid email address'
          }
          if (!values.password) {
            errors.password = 'Required';
          }
          console.log('errors', errors);
          if (errors.email === undefined)
            setIsValidEmail(true);
          else
            setIsValidEmail(false);
          if (errors.password === undefined)
            setIsValidPassword(true);
          else
            setIsValidPassword(false);
          return errors
        }}
        onSubmit={(values, { setSubmitting }) => {
          login.mutate({ email: values.email, password: values.password });
          console.log("data: ",login.data);
          
          const token = storage.get('token');
          if (token) {
            console.log('token', token);
            onSuccess();
          }
          setSubmitting(false);
        }}
      >
        {({ values, handleChange, handleSubmit }) => (
          <form noValidate onSubmit={handleSubmit} className="w-full max-w-sm">
            <div className="md:flex md:items-center mb-6">
              <div className="md:w-1/3">
                <label className="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" htmlFor="email">
                  Email
                </label>
              </div>
              <div className="md:w-2/3">
                <input
                  className="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-purple-500"
                  id="email"
                  type="email"
                  value={values.email}
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="md:flex md:items-center mb-6">
              <div className="md:w-1/3">
                <label className="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" htmlFor="password">
                  Password
                </label>
              </div>
              <div className="md:w-2/3">
                <input
                  className="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-purple-500"
                  id="password"
                  type="password"
                  value={values.password}
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="md:flex md:items-center">
              <div className="md:w-1/3"></div><div className="md:w-2/3">
                <button
                  className={`shadow bg-purple-500 hover:bg-purple-600 focus:shadow-outline-purple focus:outline-none text-white font-bold py-2 px-4 rounded ${!values.email || !values.password ? 'opacity-50 bg-gray-400 hover:bg-gray-400' : ''}`}
                  type="submit"
                  disabled={!values.email || !values.password}
                >
                  Log In
                </button>
              </div>
            </div>
          </form>
        )}
      </Formik>
    </div >
  )
}
