export type BaseEntity = {
  id: string;
  createdAt: number;
};
